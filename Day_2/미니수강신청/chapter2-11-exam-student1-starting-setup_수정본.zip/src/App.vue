<template>
  <div class="container">
    <!-- [가이드] TODO 1~15: 폼 + 유효성 검사 기반 컴포넌트 -->
    <!-- [TODO 1] submit 기본 동작 방지: 새로고침 막고 onSubmit 실행 -->
    <!-- [TODO 2] novalidate: 브라우저 기본 검증 끄고, 우리가 만든 검증 사용 -->
    <form class="card">
      <h2>미니 수강 신청 앱 실습</h2>

      <!-- ===================== 이름 ===================== -->
      <!-- [TODO 3] :class로 invalid 스타일 제어 (검증 실패 시 빨간 테두리 등) -->
      <div class="field">
        <label for="name">이름 *</label>

        <!-- [TODO 4] v-model.trim 바인딩: 앞뒤 공백 자동 제거 -->
        <!-- [TODO 5] @blur 시 단일 필드 검사 -->
        <input id="name" placeholder="홍길동" />

        <!-- [TODO 6] 에러 메시지 출력 (v-if) -->
        <small class="error"></small>
      </div>

      <!-- ===================== 이메일 ===================== -->
      <div class="field" :class="{ invalid: errors.email }">
        <label for="email">이메일 *</label>

        <!-- [TODO 7] v-model.trim + @blur validateField('email') -->
        <input id="email" type="email" placeholder="user@example.com" />

        <small v-if="errors.email" class="error">{{ errors.email }}</small>
      </div>

      <!-- ===================== 전화 ===================== -->
      <div class="field" :class="{ invalid: errors.phone }">
        <label for="phone">전화번호 *</label>

        <!-- [TODO 8] v-model.trim + @blur validateField('phone') -->
        <input id="phone" placeholder="010-1234-5678" />

        <small v-if="errors.phone" class="error">{{ errors.phone }}</small>
      </div>

      <!-- ===================== 나이 ===================== -->
      <div class="field" :class="{ invalid: errors.age }">
        <label for="age">나이(1~120) *</label>

        <!-- [TODO 9] v-model.number: 입력값을 숫자로 변환해서 저장 -->
        <!-- [TODO 10] @blur validateField('age') -->
        <input id="age" type="number" min="1" max="120" placeholder="예: 29" />

        <small v-if="errors.age" class="error">{{ errors.age }}</small>
      </div>

      <!-- [TODO 11] 제출 버튼 -->
      <input class="btn" type="button" value="제출" />

      <!-- [TODO 12] 제출 결과 메시지:
           - submitMsg에 "확인"이 들어가면 bad
           - submitMsg에 "성공"이 들어가면 ok
      -->
      <p v-if="submitMsg" class="msg">
        {{ submitMsg }}
      </p>
    </form>

    <!-- [TODO 13] EnrollList에 목록 전달(props) + 삭제 이벤트 수신 -->
  </div>
</template>

<script setup>
/**
 * [가이드] TODO 1~15 구현 포인트 요약 :contentReference[oaicite:1]{index=1}
 * - 각 입력: v-model, @blur validateField
 * - validateAll: 전체 검사
 * - 제출 시: 전체 검사 + 이메일 중복 방지(대소문자/공백 무시)
 * - 성공 시: 목록 추가 + "제출 성공!" + 폼 초기화
 * - 삭제: EnrollList/EnrollItem emit('remove') 흐름으로 처리
 */
import { reactive, ref } from "vue";
import EnrollList from "./components/EnrollList.vue";

/* ===================== 데이터 저장소 ===================== */
/** [TODO 14] 신청 목록 저장 (ref 배열) */
const enrolls = ref(); // 등록된 신청 목록
let seq = 1; // 각 신청 고유 ID 번호

/* ===================== 폼 입력값 ===================== */
/** [TODO 15] 반응형 폼 데이터 */
const form = reactive();

/* ===================== 에러 메시지 저장소 ===================== */
const errors = reactive({ name: "", email: "", phone: "", age: "" });

/**
 * 단일 필드 유효성 검사
 * - name: 필수 + 2~20자
 * - email: 필수 + 간단 이메일 정규식
 * - phone: 필수 + 010-1234-5678 형식(하이픈 있어도/없어도 일부 허용)
 * - age: 필수 + 숫자 + 1~120
 */
function validateField(field) {
  // form[field]가 undefined/null일 수 있으니 ""로 안전 처리 후 trim
  const v = String(form[field] ?? "").trim();

  if (field === "name") {
    errors.name = !v
      ? "이름은 필수입니다."
      : v.length < 2 || v.length > 20
        ? "2~20자 입력"
        : "";
  }

  if (field === "email") {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
    errors.email = !v
      ? "이메일은 필수입니다."
      : !re.test(v)
        ? "이메일 형식 확인"
        : "";
  }

  if (field === "phone") {
    const re = /^0\d{1,2}-?\d{3,4}-?\d{4}$/;
    errors.phone = !v
      ? "전화번호는 필수입니다."
      : !re.test(v)
        ? "예: 010-1234-5678"
        : "";
  }

  if (field === "age") {
    const n = Number(form.age);
    errors.age =
      v === ""
        ? "나이는 필수입니다."
        : Number.isNaN(n)
          ? "숫자 입력"
          : n < 1 || n > 120
            ? "1~120 범위"
            : "";
  }
}

/**
 * 모든 필드 유효성 검사
 * - validateField를 전부 호출해서 errors를 채우고
 * - errors 값이 전부 비어있으면 통과
 */
function validateAll() {
  Object.keys(form).forEach((f) => validateField(f));
  return Object.values(errors).every((msg) => !msg);
}

/** 제출 결과 메시지 */
const submitMsg = ref("");

/**
 * 제출 이벤트 처리
 * - 전체 검사 + 이메일 중복 체크(대소문자/공백 무시)
 * - 성공 시 목록 추가 + 메시지 + 폼 초기화
 */
async function onSubmit() {
  submitMsg.value = "";

  // [가이드] 이메일 중복체크(대소문자/공백 무시)
  const duplicate = enrolls.value.some(
    (e) =>
      e.email.trim().toLowerCase() === String(form.email).trim().toLowerCase(),
  );

  // 유효성 검사 실패 또는 이메일 중복이면 오류 메시지
  if (!validateAll() || duplicate) {
    submitMsg.value = "입력값을 확인해주세요.";
    return;
  }

  // 정상 등록 처리
  enrolls.value.push({
    id: seq++,
    name: form.name.trim(),
    email: form.email.trim(),
    phone: form.phone.trim(),
    age: Number(form.age),
  });

  submitMsg.value = "제출 성공!";

  // 폼 초기화
  Object.assign(form, { name: "", email: "", phone: "", age: "" });
}

/**
 * 수강 신청 항목 삭제
 * - EnrollItem -> EnrollList -> App 으로 remove 이벤트가 올라오며
 * - App에서 실제로 배열을 갱신한다.
 */
function removeOne(id) {
  enrolls.value = enrolls.value.filter((e) => e.id !== id);
}
</script>

<style scoped>
.container {
  max-width: 900px;
  margin: 32px auto;
  padding: 8px;
}
.card {
  max-width: 520px;
  margin: 24px auto;
  padding: 18px;
  border: 1px solid #e5e7eb;
  border-radius: 12px;
  background: #fff;
  font-family:
    system-ui,
    -apple-system,
    Segoe UI,
    Roboto,
    Apple SD Gothic Neo,
    sans-serif;
}
h2 {
  margin: 0 0 12px;
  font-size: 18px;
}
.field {
  display: grid;
  gap: 6px;
  margin-bottom: 12px;
}
label {
  font-size: 14px;
  color: #374151;
}
input {
  padding: 10px 12px;
  border: 1px solid #d1d5db;
  border-radius: 10px;
  outline: none;
}
input:focus {
  border-color: #6366f1;
  box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.15);
}
.field.invalid input {
  border-color: #ef4444;
  box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.12);
}
.error {
  color: #b91c1c;
  font-size: 12px;
}
.btn {
  width: 100%;
  padding: 12px;
  border: 0;
  border-radius: 10px;
  background: #4f46e5;
  color: #fff;
  font-weight: 600;
  cursor: pointer;
}
.btn:hover {
  filter: brightness(1.05);
}
.msg {
  margin-top: 8px;
  font-size: 14px;
}
.msg.ok {
  color: #065f46;
}
.msg.bad {
  color: #b91c1c;
}
</style>
