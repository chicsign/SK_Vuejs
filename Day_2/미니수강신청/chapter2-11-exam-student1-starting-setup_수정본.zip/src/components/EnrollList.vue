<template>
  <!-- [가이드] TODO 16~20: 목록 컴포넌트
       - items 배열을 props로 받아 목록 렌더링
       - 데이터가 없으면 v-if, 있으면 v-else
       - v-for로 EnrollItem 반복 출력
       - 삭제는 emit('remove', id) 형태로 부모에게 전달
  -->
  <section class="panel">
    <h3>신청 목록</h3>

    <!-- [TODO 16] v-if / v-else 최소 1회:
         items.length === 0 이면 안내 문구 출력
    -->
    <p class="empty">아직 신청이 없습니다.</p>

    <!-- [TODO 17] v-else: items가 있으면 목록 출력 -->
    <ul class="list">
      <!-- [TODO 18] v-for 최소 1회:
           - items 배열을 순회하며 EnrollItem 렌더링
           - :key는 고유값 id 사용
      -->

      <!-- [TODO 19] 자식(EnrollItem)의 remove를 받아
             부모(App)에게 remove 이벤트로 id를 전달
        -->
      <EnrollItem />
    </ul>
  </section>
</template>

<script setup>
/**
 * [TODO 20] props / emit / 컴포넌트 import
 * - items: 신청 목록 배열
 * - remove: 삭제 이벤트 (id를 함께 올려 보냄)
 */
import { defineProps, defineEmits } from "vue";
import EnrollItem from "./EnrollItem.vue";

defineProps();

defineEmits(); // (id) 형태로 부모에게 전달
</script>

<style scoped>
.panel {
  max-width: 720px;
  margin: 0 auto 24px;
}
h3 {
  margin: 8px 0 12px;
}
.empty {
  color: #6b7280;
}
.list {
  list-style: none;
  padding-left: 0;
  display: grid;
  gap: 10px;
}
</style>
