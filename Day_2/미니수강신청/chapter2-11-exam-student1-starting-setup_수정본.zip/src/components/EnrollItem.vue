<template>
  <!-- [가이드] TODO 21~23: 목록 아이템 컴포넌트
       - props로 item(신청자 정보) 받기
       - 삭제 버튼 클릭 시 emit('remove')로 부모에게 삭제 요청
  -->
  <li class="row">
    <div class="left">
      <div class="name">
        <!-- [TODO 21] props로 받은 item.name 표시 -->
        <strong>홍길동</strong>

        <!-- 이메일은 <> 형태로 보여주기 -->
        <span class="muted">&lt;{{ item.email }}&gt;</span>
      </div>

      <div class="meta">
        <!-- [TODO 21] 전화/나이 표시 -->
        <span class="badge"> 010</span>
        <span class="badge">나이: 20</span>
      </div>
    </div>

    <div class="right">
      <!-- [TODO 22] 삭제 이벤트 방출
           - 이 컴포넌트는 "삭제 로직"을 직접 처리하지 않음
           - 부모(EnrollList/App)가 실제 삭제를 수행 (단방향 데이터 흐름)
      -->
      <button class="danger">삭제</button>
    </div>
  </li>
</template>

<script setup>
/**
 * [TODO 23] props / emit 정의
 * - defineProps: 부모로부터 item 객체를 받는다.
 * - defineEmits: remove 이벤트를 외부로 알린다.
 */
import { defineProps, defineEmits } from "vue";

defineProps();

defineEmits(); // 삭제 요청 이벤트
</script>

<style scoped>
.row {
  display: grid;
  grid-template-columns: 1fr auto;
  align-items: center;
  border: 1px solid #eee;
  border-radius: 12px;
  padding: 12px;
}
.name {
  display: flex;
  gap: 8px;
  align-items: baseline;
}
.muted {
  color: #6b7280;
  font-size: 12px;
}
.meta {
  margin-top: 6px;
  display: flex;
  gap: 6px;
}
.badge {
  background: #eef3ff;
  color: #374151;
  padding: 2px 8px;
  border-radius: 999px;
  font-size: 12px;
}
.right {
  display: inline-flex;
  gap: 8px;
}
button {
  padding: 8px 12px;
  border-radius: 10px;
  border: none;
  cursor: pointer;
  font-weight: 700;
}
button.danger {
  background: #ef4444;
  color: #fff;
}
</style>
