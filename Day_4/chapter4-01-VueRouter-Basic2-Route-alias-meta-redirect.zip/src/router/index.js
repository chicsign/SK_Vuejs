// index.js
import { createRouter, createWebHistory } from "vue-router";

import Home from "../views/Home.vue";
import About from "../views/About.vue";
import Admin from "../views/Admin.vue";

const routes = [
  // 1) alias: / 또는 /start 로 접근 가능
  { path: "/", alias: "/start", component: Home },

  // 2) redirect: /go-about 으로 접근하면 /about 으로 자동 이동
  { path: "/go-about", redirect: "/about" },
  { path: "/about", component: About },

  // 3) meta: 인증이 필요한 페이지 (관리자 페이지)
  {
    path: "/admin",
    component: Admin,
    meta: { requiresAuth: true, role: "admin" },
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
