<!-- App.vue -->
<template>
  <nav>
    <!-- 링크: 최소한의 네비게이션 -->
    <RouterLink to="/">Home</RouterLink> |
    <RouterLink to="/start">Home(alias:/start)</RouterLink> |
    <RouterLink to="/go-about">Go About(redirect)</RouterLink> |
    <RouterLink to="/about">About</RouterLink> |
    <RouterLink to="/admin">Admin(meta)</RouterLink>
  </nav>

  <!-- 라우트가 바뀌면 여기 내용이 교체됨 -->
  <RouterView />
</template>

<script setup>
// Composition API 사용 (별도 로직 없음)
</script>

<style>
/* 최소 스타일: 보기 편하게 살짝만 */
nav {
  padding: 8px;
}
a {
  text-decoration: none;
  margin: 0 4px;
}
</style>
