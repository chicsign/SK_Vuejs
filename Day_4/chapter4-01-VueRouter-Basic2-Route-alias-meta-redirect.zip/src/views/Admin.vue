<!-- Admin.vue -->
<template>
  <h1>Admin</h1>
  <p>여기는 관리자 페이지입니다.</p>
</template>
<script setup>
import { useRoute } from "vue-router";

// 현재 라우트 정보 가져오기
const route = useRoute();

//meta 참조
console.log("meta 참조: ", route.meta.requiresAuth, route.meta.role);
</script>
