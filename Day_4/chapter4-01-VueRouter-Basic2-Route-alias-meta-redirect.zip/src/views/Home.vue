<!-- Home.vue -->
<template>
  <h1>Home</h1>
  <p>여기는 홈 페이지입니다.</p>
</template>
<script setup></script>
