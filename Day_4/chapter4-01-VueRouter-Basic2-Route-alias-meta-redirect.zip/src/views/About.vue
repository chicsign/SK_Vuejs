<!-- About.vue -->
<template>
  <h1>About</h1>
  <p>여기는 소개 페이지입니다.</p>
</template>
<script setup></script>
